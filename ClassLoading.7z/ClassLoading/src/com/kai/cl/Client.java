package com.kai.cl;

import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;

public class Client {

	public static void main(String[] args) throws ClassNotFoundException,
			InstantiationException, IllegalAccessException,
			MalformedURLException {

		URLClassLoader cl = new URLClassLoader(
				new URL[] { new URL(
						"file:///C:/Users/lenovo/Desktop/PluralSight/understanding-java-vm-class-loading-reflection/3-understanding-java-vm-class-loading-reflection-m3-exercise-files/SimpleClassloading/lib/Quoter.jar") });
		// Class clazz = Class.forName("com.mantiso.Quote", true, cl);
		Class clazz = cl.loadClass("com.mantiso.Quote");
		System.out.println(clazz.getCanonicalName());
	}

	public static void forNameEg() throws InstantiationException,
			IllegalAccessException, ClassNotFoundException {
		Class cl = Class.forName("com.kai.cl.Car");
		Car car = (Car) cl.newInstance();
		car.setName("BMW");
		System.out.println(car.getName());
	}

	public static void delegationEg() {

		URLClassLoader cl = (URLClassLoader) ClassLoader.getSystemClassLoader();
		do {
			System.out.println(cl);
			for (URL url : cl.getURLs()) {
				System.out.println(url.getPath());
			}
		} while ((cl = (URLClassLoader) cl.getParent()) != null);

		System.out.println("BootStrap class loader written in C");
	}
}
