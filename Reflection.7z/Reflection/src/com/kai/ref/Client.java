package com.kai.ref;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.List;

public class Client {

	public static void main(String[] args) throws ClassNotFoundException,
			InstantiationException, IllegalAccessException,
			IllegalArgumentException, InvocationTargetException {

		Class cl = Class.forName("com.kai.ref.Car");
		System.out.println(cl.getName());

		for (Field field : cl.getDeclaredFields()) {
			System.out.println(field.getName());
		}

		System.out.println("#######");

		Constructor[] cons = cl.getConstructors();
		Car car = (Car) cons[0].newInstance("Merc");

		System.out.println("Cont...");
	}
}
