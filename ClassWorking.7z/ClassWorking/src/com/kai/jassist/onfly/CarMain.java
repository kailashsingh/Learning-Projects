package com.kai.jassist.onfly;

public class CarMain {

	public static void main(String[] args) {
		drive();
		System.out.println("Driven");
	}
	
	public static void drive(){
		System.out.println("starts driving...");
	}
}
