package com.kai.jassist.onfly;

import javassist.CannotCompileException;
import javassist.ClassPool;
import javassist.Loader;
import javassist.NotFoundException;
import javassist.Translator;

public class JavassistRun {
	public static void main(String[] args) throws Throwable {
		// set up class loader with translator
		Translator xlat = new VerboseTranslator();
		ClassPool pool = ClassPool.getDefault();
		Loader loader = new Loader(pool);
		loader.addTranslator(pool, xlat);

		// invoke "main" method of target class
		String[] pargs = new String[args.length - 1];
		System.arraycopy(args, 1, pargs, 0, pargs.length);
		loader.run(args[0], pargs);
	}

	public static class VerboseTranslator implements Translator {
		@Override
		public void onLoad(ClassPool pool, String cname)
				throws NotFoundException, CannotCompileException {
			System.out.println("onLoad called for " + cname);
		}

		@Override
		public void start(ClassPool arg0) throws NotFoundException,
				CannotCompileException {
			// TODO Auto-generated method stub

		}
	}
}
