package com.kai.jassist.selective;

public class CarMain {

	public static void main(String[] args) {
		System.out.println("Car Main");
		Car car = new Car();
		car.drive();
		car.stop();
	}

}
