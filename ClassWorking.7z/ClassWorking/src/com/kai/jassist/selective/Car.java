package com.kai.jassist.selective;

public class Car {

	public void drive(){
		System.out.println("starts driving...");
	}
	
	public void stop(){
		System.out.println("stops driving...");
	}
}
